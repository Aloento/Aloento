
from numpy import loadtxt
from keras.models import Sequential
from keras.layers import Dense, Conv1D, MaxPooling1D, Flatten, Dropout
from matplotlib import pyplot as plt
from sklearn.model_selection import train_test_split

# Load the dataset
dataset = loadtxt('mushroom_cleaned.csv', delimiter=',')
# Split into input (X) and output (y) variables
X = dataset[:, 0:8].astype('float64')  # Convert input to float64
y = dataset[:, 8].astype('float64')  # Convert output to float64

# Print the shapes
print("Shape of X:", X.shape)  # Should be (n_samples, 8)
print("Shape of y:", y.shape)  # Should be (n_samples,)

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
# Reshape X for compatibility with Conv1D layer
X_train = X_train.reshape(X_train.shape[0], X_train.shape[1], 1)
X_test = X_test.reshape(X_test.shape[0], X_test.shape[1], 1)

# Define the CNN architecture
model = Sequential([
    Conv1D(filters=32, kernel_size=2, activation='relu', input_shape=(8, 1)),
    MaxPooling1D(pool_size=2),
    Conv1D(filters=64, kernel_size=2, activation='relu'),
    MaxPooling1D(pool_size=2),
    Flatten(),
    Dense(64, activation='relu'),
    Dropout(0.5),
    Dense(1, activation='sigmoid')
])

# Compile the Keras model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
# Fit the Keras model on the dataset
history = model.fit(X_train, y_train, epochs=150, batch_size=128, validation_split=0.2)
# Evaluate the Keras model
loss, accuracy = model.evaluate(X_test, y_test)
print(f"Test Loss: {loss:.4f}")
print(f"Test Accuracy: {accuracy:.4f}")


# Plot accuracy and loss over epochs
plt.figure(figsize=(12, 4))
# Plot accuracy
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Training Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()
plt.title('Model Accuracy')
# Plot loss
plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.title('Model Loss')
plt.tight_layout()
plt.show()
