import numpy as np
import random

# Q-learning agent class
class QLearning:
    def __init__(self, n_states, n_actions, learning_rate):
        self.n_states = n_states
        self.n_actions = n_actions
        self.learning_rate = learning_rate

        self.q_table = np.zeros((n_states, n_actions))

    def act(self, state, epsilon):
        if random.uniform(0, 1) < epsilon:
            return random.randint(0, self.n_actions - 1)
        else:
            return np.argmax(self.q_table[state])

    def learn(self, state, action, reward, new_state, gamma):
        best_next_action = np.argmax(self.q_table[new_state])
        td_target = reward + gamma * self.q_table[new_state][best_next_action]
        td_error = td_target - self.q_table[state][action]
        self.q_table[state][action] += self.learning_rate * td_error


# Create an instance of the Q-learning agent with different parameters
# Write your code below this line!
n_states = 5
n_actions = 3
learning_rate = 0.1
agent = QLearning(n_states, n_actions, learning_rate)

# Selecting an action for state 2 with epsilon = 0.1
# Write your code below this line!
state = 2
epsilon = 0.1
selected_action = agent.act(state, epsilon)
# Update the Q-values for a transition from state 1 to state 3 with action 2, reward 3, and discount factor 0.5
# Write your code below this line!
current_state = 1
action = 2
reward = 3
new_state = 3
gamma = 0.5
agent.learn(current_state, action, reward, new_state, gamma)

# Printing the Q-table
# Remove comments to test the code

print("Q-Table after Learning:")
print(agent.q_table)
