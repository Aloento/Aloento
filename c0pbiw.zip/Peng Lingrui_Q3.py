from mt_utils import *


class TurningCups(Problem):

    def __init__(self):
        # Complete the implementation of initial function by calling
        # the parent constructor and initialize the initial state and set of goal states

        # Write your code below this line!
        initial_state = (0, 0, 0, 0, 0, 0)
        goal_state = (1, 1, 1, 1, 1, 1)
        super().__init__(initial_state, goal_state)
        # Write your code above this line! Delete the 'pass' keyword!

    def actions(self, state):
        # Complete the implementation of possible operators.
        # The function should return all next possible actions from the input state.

        acts = []
        # Write your code below this line!
        for i in range(6):
            for j in range(6):
                if i != j and state[i] == 0 and state[j] == 0:
                    acts.append((i + 1, j + 1))
        # Write your code above this line!
        return acts

    def result(self, state, action):
        # Fill in the missing parts of the transition function

        i, j = action
        new_state = list(state)
        # Write your code below this line!
        i, j = i - 1, j - 1
        if new_state[i] == 0:
            new_state[i] = 1
        if new_state[j] == 0:
            new_state[j] = 1
        # Write your code above this line!
        return tuple(new_state)


def breadth_first_graph_search(problem):
    # Write your code below this line!
    frontier = deque([Node(problem.initial)])
    explored = set()

    while frontier:
        node = frontier.popleft()
        if problem.goal_test(node.state):
            return node
        explored.add(node.state)
        for action in problem.actions(node.state):
            child = node.child_node(problem, action)
            if child.state not in explored and child not in frontier:
                frontier.append(child)
    return None
    # Write your code above this line! Delete the 'pass' keyword


def main():
    # DO NOT EDIT this function!
    t = TurningCups()
    # 1. Exercise: Fill in the missing parts of init method
    print(t.initial, t.goal)  # Expected output: (0,0,0,0,0,0), (1,1,1,1,1,1)
    # 2. Exercise: Fill in the missing parts of actions method
    print(t.actions(
        t.initial))  # Expected output: [(1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (2, 1), (2, 3),..., (6, 4), (6, 5)]
    # 3. Exercise: Fill in the missing parts of result method
    print(t.result(t.initial, (2, 3)))  # Expected output: (0, 1, 1, 0, 0, 0)
    # 4. Exercise: Fill in the missing parts of the search algorithm
    print(breadth_first_graph_search(t))  # Expected output: <Node (1, 1, 1, 1, 1, 1)>


if __name__ == '__main__':
    main()
